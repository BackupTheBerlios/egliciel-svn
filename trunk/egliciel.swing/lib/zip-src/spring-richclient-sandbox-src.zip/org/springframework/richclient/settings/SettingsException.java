package org.springframework.richclient.settings;

public class SettingsException extends Exception {
	public SettingsException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
