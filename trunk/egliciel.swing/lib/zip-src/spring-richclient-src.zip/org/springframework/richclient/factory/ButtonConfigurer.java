/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/richclient/factory/ButtonConfigurer.java,v 1.3 2004/10/31 18:58:34 kdonald Exp $
 * $Revision: 1.3 $
 * $Date: 2004/10/31 18:58:34 $
 * 
 * Copyright Computer Science Innovations (CSI), 2004. All rights reserved.
 */
package org.springframework.richclient.factory;

import javax.swing.AbstractButton;

/**
 * @author Keith Donald
 */
public interface ButtonConfigurer {
    public AbstractButton configure(AbstractButton button);
}