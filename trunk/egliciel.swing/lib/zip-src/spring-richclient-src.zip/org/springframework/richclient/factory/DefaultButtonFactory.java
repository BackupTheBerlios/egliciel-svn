/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/richclient/factory/DefaultButtonFactory.java,v 1.6 2004/11/15 05:43:48 kdonald Exp $
 * $Revision: 1.6 $
 * $Date: 2004/11/15 05:43:48 $
 * 
 * Copyright Computer Science Innovations (CSI), 2004. All rights reserved.
 */
package org.springframework.richclient.factory;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;

import org.springframework.util.Assert;

/**
 * @author Keith Donald
 */
public class DefaultButtonFactory implements ButtonFactory {

    private static ButtonFactory INSTANCE = new DefaultButtonFactory();

    public static final ButtonFactory instance() {
        return INSTANCE;
    }

    public static void load(DefaultButtonFactory instance) {
        Assert.notNull(instance, "The sole default button factory instance is required");
        INSTANCE = instance;
    }

    public JButton createButton() {
        return new JButton();
    }

    public JMenuItem createMenuItem() {
        return new JMenuItem();
    }

    public JCheckBox createCheckBox() {
        return new JCheckBox();
    }

    public JToggleButton createToggleButton() {
        return new JToggleButton();
    }

    public JRadioButton createRadioButton() {
        return new JRadioButton();
    }
}