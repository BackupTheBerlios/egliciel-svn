/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/richclient/factory/MenuFactory.java,v 1.4 2004/10/31 18:58:34 kdonald Exp $
 * $Revision: 1.4 $
 * $Date: 2004/10/31 18:58:34 $
 * 
 * Copyright Computer Science Innovations (CSI), 2004. All rights reserved.
 */
package org.springframework.richclient.factory;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;

/**
 * @author Keith Donald
 */
public interface MenuFactory {
    public JMenu createMenu();

    public JMenuItem createMenuItem();

    public JCheckBoxMenuItem createCheckBoxMenuItem();

    public JRadioButtonMenuItem createRadioButtonMenuItem();

    public JPopupMenu createPopupMenu();

    public JMenuBar createMenuBar();

}