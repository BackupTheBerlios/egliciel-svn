/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/richclient/factory/ButtonFactory.java,v 1.3 2004/10/31 18:58:34 kdonald Exp $
 * $Revision: 1.3 $
 * $Date: 2004/10/31 18:58:34 $
 * 
 * Copyright Computer Science Innovations (CSI), 2004. All rights reserved.
 */
package org.springframework.richclient.factory;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;

/**
 * @author Keith Donald
 */
public interface ButtonFactory {
    public JButton createButton();

    public JCheckBox createCheckBox();

    public JToggleButton createToggleButton();

    public JRadioButton createRadioButton();
}