/*
 * Created on Dec 1, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.springframework.richclient.text;

import javax.swing.text.JTextComponent;

/**
 * @author Oliver Hutchison
 */
public interface TextComponentContainer {

    public JTextComponent getComponent();
}
