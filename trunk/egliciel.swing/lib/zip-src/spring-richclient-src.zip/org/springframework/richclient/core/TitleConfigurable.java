/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/richclient/core/TitleConfigurable.java,v 1.6 2004/10/31 18:58:45 kdonald Exp $
 * $Revision: 1.6 $
 * $Date: 2004/10/31 18:58:45 $
 * 
 * Copyright Computer Science Innovations (CSI), 2004. All rights reserved.
 */
package org.springframework.richclient.core;

/**
 * Implementing by application objects whose titles are configurable; for
 * example, dialogs or wizard pages.
 * 
 * @author Keith Donald
 */
public interface TitleConfigurable {

    /**
     * Sets the title.
     * 
     * @param title
     *            the title
     */
    public void setTitle(String title);
}