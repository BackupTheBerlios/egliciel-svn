/*
 * $Header: /cvsroot/spring-rich-c/spring-richclient/src/org/springframework/rules/reporting/ValidationResults.java,v 1.1 2005/07/26 23:14:12 ohutchison Exp $
 * $Revision: 1.1 $
 * $Date: 2005/07/26 23:14:12 $
 *
 * Copyright Computer Science Innovations (CSI), 2003. All rights reserved.
 */
package org.springframework.rules.reporting;

import org.springframework.core.closure.Constraint;

/**
 * @author  Keith Donald
 */
public interface ValidationResults {

	/**
	 * @return Returns the rejectedValue.
	 */
	public Object getRejectedValue();

	/**
	 * @return Returns the violatedConstraint.
	 */
	public Constraint getViolatedConstraint();

	/**
	 * @return Returns the violatedCount.
	 */
	public int getViolatedCount();

	/**
	 * @return Returns the severity.
	 */
	public Severity getSeverity();
}