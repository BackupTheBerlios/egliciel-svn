/*
 * Copyright 2002-2005 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.springframework.binding.form;

import org.springframework.binding.form.support.DefaultBindingErrorMessageProvider;
import org.springframework.binding.validation.ValidationMessage;

/**
 * A class that can generate ValidationMessages for exception that occur
 * during a form model's binding process.
 * 
 * @author  Oliver Hutchison
 * @see DefaultBindingErrorMessageProvider
 */
public interface BindingErrorMessageProvider {
    
    /**
     * Translates the provided exception details into a ValidationMessage that
     * will be used to provide feedback to the end user. General these 
     * exceptions results from type conversion problems. 
     */
    ValidationMessage getErrorMessage(FormModel formModel, String propertyName, Object valueBeingSet, Exception e); 

}
